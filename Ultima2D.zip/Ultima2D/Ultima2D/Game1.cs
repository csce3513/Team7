#region Using Statements
using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion
using Ultima2D.Ultima;
using Ultima2D.IBLib;
namespace Ultima2D
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public partial class Ultima2D : Microsoft.Xna.Framework.Game
    {
        bool debugMode = true;

        GraphicsDeviceManager graphics;
        ContentManager content;
        GraphicsDevice device;

        int GameWidthWindowed = 800
            , GameHeightWindowed = 600;
        int GameWidthFull = 1024,
            GameHeightFull = 768;
        int GameWidth = 800,
            GameHeight = 600;
        bool fullscreen = false;
        public Ultima2D()
        {
            graphics = new GraphicsDeviceManager(this);
            content = new ContentManager(Services);
           Content.RootDirectory = "Content";
            InitializeXna();
        }
        void InitializeXna()
        {
            if (fullscreen)
            {
                GameWidth = GameWidthFull; GameHeight = GameHeightFull;
            }
            else
            {
                GameWidth = GameWidthWindowed; GameHeight = GameHeightWindowed;
            }
            graphics.PreferredBackBufferWidth = GameWidth;
            graphics.PreferredBackBufferHeight = GameHeight;
            graphics.IsFullScreen = fullscreen;
            graphics.ApplyChanges();
        }
    }
}
