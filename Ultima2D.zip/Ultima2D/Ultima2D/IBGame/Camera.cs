#region Using Statements
using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion
using Ultima2D.Ultima;
using Ultima2D.IBLib;
namespace Ultima2D
{
    public partial class Ultima2D : Microsoft.Xna.Framework.Game
    {
        float cameraSpeed,viewPortSpeed;
        bool stickToThePlayer;
        Viewport defaultViewPort, scrolledViewPort;
        Point offsetPoint;
        void InitializeCamera()
        {
            stickToThePlayer = true;
            cameraSpeed = 6f; viewPortSpeed = 14f;
            scrolledViewPort = defaultViewPort = graphics.GraphicsDevice.Viewport;
            warpCameraToPlayer();
        }

        // Camera Methods
        void moveCamera(Directions d)
        {
            switch (d) // Move ViewPorts
            {
                case (Directions.Left):
                    offsetPoint.X -= (int)cameraSpeed;
                    break;
                case (Directions.Right):
                    offsetPoint.X += (int)cameraSpeed;
                    break;
                case (Directions.Up):
                    offsetPoint.Y += (int)cameraSpeed;
                    break;
                case (Directions.Down):
                    offsetPoint.Y -= (int)cameraSpeed;
                    break;
            }
            restrictCamera();

        }
        void warpCamera(Point p)
        {
            offsetPoint.X = p.X;
            offsetPoint.Y = p.Y;
            restrictCamera();
        }
        void moveCameraWithPlayer(int deltaX)
        {
            //if ((offsetPoint.X-cameraSpeed ) <= 0 )//&& offsetPoint.X + GameWidth  <= world.bounds.Right)
            //{
            if (world.player.bounds.X - deltaX < Math.Abs(offsetPoint.X - GameWidth / 2)) moveCamera(Directions.Right);
            if (world.player.bounds.X + deltaX > Math.Abs(offsetPoint.X - GameWidth / 2)) moveCamera(Directions.Left);
            //}
            if (world.player.bounds.Y < Math.Abs(offsetPoint.Y - GameHeight / 2)) moveCamera(Directions.Up);
            if (world.player.bounds.Y > Math.Abs(offsetPoint.Y - GameHeight / 2)) moveCamera(Directions.Down);
        }
        public void warpCameraToPlayer()
        {
            warpCamera(new Point(
                -world.player.bounds.Left + GameWidth / 2,
                -world.player.bounds.Top + GameHeight / 2));
        }
        void restrictCamera()
        {
            if (offsetPoint.X > -5) offsetPoint.X = -5;
            if (offsetPoint.Y < -(world.rows * BlockConstants.BlockHeight - GameHeight)) offsetPoint.Y = -(world.rows * BlockConstants.BlockHeight - GameHeight);
            if (offsetPoint.Y > 0) offsetPoint.Y = 0;
            Rectangle worldarea = world.getArea();
            if (offsetPoint.X - 5 - GameWidth < -worldarea.Width) offsetPoint.X = -worldarea.Width + GameWidth + 5;
            if (offsetPoint.Y + 105 + GameHeight > worldarea.Height) offsetPoint.Y = worldarea.Height - GameHeight - 105;
            //if (offsetPoint.Y + (world.rows * BlockConstants.BlockHeight - GameHeight) > worldarea.Height) offsetPoint.Y = worldarea.Height - (world.rows * BlockConstants.BlockHeight - GameHeight);

        }

        // Viewport Methods
        void warpViewPort(Point p)
        {
            scrolledViewPort.X = p.X;
            scrolledViewPort.Y = p.Y;
            resetViewPort();
        }
        void zoomViewPort(int direction)
        {
            scrolledViewPort.Height += (int)(viewPortSpeed * (direction));
            scrolledViewPort.Width += (int)(viewPortSpeed * (direction));
            if (scrolledViewPort.Height < GameHeight) scrolledViewPort.Height = GameHeight;
            if (scrolledViewPort.Width < GameWidth) scrolledViewPort.Width = GameWidth;
        }
        void moveViewPort(Directions d)
        {
            switch (d) // Move ViewPorts
            {
                case (Directions.Left):
                    scrolledViewPort.X -= (int)viewPortSpeed ;
                    break;
                case (Directions.Right):
                    scrolledViewPort.X += (int)viewPortSpeed;
                    break;
                case (Directions.Up):
                    scrolledViewPort.Y += (int)viewPortSpeed;
                    break;
                case (Directions.Down):
                    scrolledViewPort.Y -= (int)viewPortSpeed;
                    break;
            }

            resetViewPort();
        }
        void resetViewPort()
        {
            scrolledViewPort.Width = GameWidth + (defaultViewPort.X - scrolledViewPort.X); 
            scrolledViewPort.Height = GameHeight + (defaultViewPort.Y - scrolledViewPort.Y);

            if (scrolledViewPort.X < 0)
            {
                scrolledViewPort.X = 0;
                resetViewPort();
            }

            if (scrolledViewPort.Y < 0)
            {
                scrolledViewPort.Y = 0;
                resetViewPort();
            }
        }
        void bringDownGame(int offset)
        {
            if (scrolledViewPort.Y > (defaultViewPort.Y - offset)) 
                moveViewPort(Directions.Up);
        }
        void bringUpGame()
        {
            if (scrolledViewPort.Y > 0)
                moveViewPort(Directions.Down);
        }
    }
}