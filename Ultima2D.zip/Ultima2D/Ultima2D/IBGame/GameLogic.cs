#region Using Statements
using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion
using Ultima2D.Ultima;
using Ultima2D.IBLib;
using Ultima2D.IBGame;
namespace Ultima2D
{
    public partial class Ultima2D : Microsoft.Xna.Framework.Game
    {
        World world;

        bool gameRunning;
        GameState state;
        public GameTime gamesTime;

        public void nextLevel()
        {
            world.nextLevel(); initializeLevel();
        }

        void prevLevel()
        {
            world.prevLevel(); initializeLevel();
        }

        void warpLevel(int levelNum)
        {
            world.warpLevel(levelNum);
            initializeLevel();
        }

        void initializeLevel()
        {
            warpCameraToPlayer();
        }

        protected override void Initialize()
        {
            initializeMessages();

            sayMessage("[MSG] Ultima2D (c) 2008 Saeed Afshari.");
            InitializeWorld();
            InitializeMouse();
            InitializeKeys();
            InitializeGraphics();
            InitializeCamera();
            state = GameState.Playing;
            base.Initialize();
            sayMessage("[MSG] Ultima2D's Engine is started successfully!");
            warpLevel(0);
        }

        void InitializeWorld()
        {
            gameRunning = true;
            world = new World(this);
        }

        void behave(GameTime gameTime)
        {
            resetDebugData();
            gamesTime = gameTime;
            DebugAdd("Total Run time: " + getTime(gameTime.TotalGameTime));
            if (gameRunning)
                //&& (int)(gameTime.TotalGameTime.TotalMilliseconds) % world.behaveSpeed ==0)
                world.Behave();
            playerMovement(gameTime);
            getDebugData();
        }

        void playerMovement(GameTime gameTime)
        {
            if (stickToThePlayer) moveCameraWithPlayer(70);
        }

    }
}