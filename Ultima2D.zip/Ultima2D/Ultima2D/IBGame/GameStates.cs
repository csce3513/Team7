using System;
using System.Collections.Generic;
using System.Text;

namespace Ultima2D.IBGame
{
    enum GameState
    {
        Null,
        Pause,
        Halt,
        Playing,
        Inventory,
        Menu
    }
}
