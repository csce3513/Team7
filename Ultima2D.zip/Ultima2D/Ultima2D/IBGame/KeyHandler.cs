#region Using Statements
using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion
using Ultima2D.Ultima;
using Ultima2D.IBLib;
namespace Ultima2D
{
    public partial class Ultima2D : Microsoft.Xna.Framework.Game
    {
        void InitializeKeys()
        {
        }

        void HandleKeys(GameTime gameTime)
        {
            #region Player Controls
            //Function Keys
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed ||
                Keyboard.GetState().IsKeyDown(Keys.Escape))
                this.Exit();
            if ((Keyboard.GetState().IsKeyDown(Keys.LeftAlt) || 
                Keyboard.GetState().IsKeyDown(Keys.RightAlt)) && 
                Keyboard.GetState().IsKeyDown(Keys.Enter))
            {
                fullscreen=!fullscreen;
                InitializeXna();
            }
            //Handle Keys (Won't work if game isn't running)
            if (gameRunning)
            {
                world.HandleKeyboard(Keyboard.GetState());
                //Look Keys
                if (Keyboard.GetState().IsKeyDown(Keys.Up)) moveCamera(Directions.Up);
                if (Keyboard.GetState().IsKeyDown(Keys.Down)) moveCamera(Directions.Down);
            }
            #endregion

            #region Debug Mode Keys
            if (debugMode)
            {
                // Game Config
                if (Keyboard.GetState().IsKeyDown(Keys.MediaPlayPause)) gameRunning = !gameRunning;
                if (Keyboard.GetState().IsKeyDown(Keys.MediaStop)) InitializeWorld(); //RESET GAME
                if (Keyboard.GetState().IsKeyDown(Keys.MediaNextTrack)) nextLevel();
                if (Keyboard.GetState().IsKeyDown(Keys.MediaPreviousTrack)) prevLevel(); 
                if (Keyboard.GetState().IsKeyDown(Keys.M)) useMouse = !useMouse;

                if (Keyboard.GetState().IsKeyDown(Keys.F8))
                {
                    gameMessagesCount--;
                    if (gameMessagesCount < 1) gameMessagesCount = 1;
                    initializeMessages();
                }
                if (Keyboard.GetState().IsKeyDown(Keys.F9))
                {
                    gameMessagesCount++;
                    if (gameMessagesCount > 10) gameMessagesCount = 10;
                    initializeMessages();
                }
                //Camera Movement
                if (Keyboard.GetState().IsKeyDown(Keys.A)) moveCamera(Directions.Right);
                if (Keyboard.GetState().IsKeyDown(Keys.D)) moveCamera(Directions.Left);
                if (Keyboard.GetState().IsKeyDown(Keys.W)) moveCamera(Directions.Up);
                if (Keyboard.GetState().IsKeyDown(Keys.S)) moveCamera(Directions.Down);

                if (Keyboard.GetState().IsKeyDown(Keys.B)) stickToThePlayer = !stickToThePlayer;
                if (Keyboard.GetState().IsKeyDown(Keys.N)) warpCameraToPlayer();

                //Viewport Movement
                if (Keyboard.GetState().IsKeyDown(Keys.H)) moveViewPort(Directions.Right);
                if (Keyboard.GetState().IsKeyDown(Keys.K)) moveViewPort(Directions.Left);
                if (Keyboard.GetState().IsKeyDown(Keys.U)) moveViewPort(Directions.Up);
                if (Keyboard.GetState().IsKeyDown(Keys.J)) moveViewPort(Directions.Down);

                //Viewport Scale
                if (Keyboard.GetState().IsKeyDown(Keys.Subtract)) zoomViewPort(1); //Zoom Out
                if (Keyboard.GetState().IsKeyDown(Keys.Add)) zoomViewPort(-1); //Zoom In

                //Status View
                if (Keyboard.GetState().IsKeyDown(Keys.R)) bringUpGame();
                if (Keyboard.GetState().IsKeyDown(Keys.T)) bringDownGame(150) ;
                
                //Player Speed
                if (Keyboard.GetState().IsKeyDown(Keys.O)) world.player.speed++;
                if (Keyboard.GetState().IsKeyDown(Keys.P)) world.player.speed--;
            }
            #endregion

            if (useMouse)
                HandleMouse(gameTime);
        }
    }
}