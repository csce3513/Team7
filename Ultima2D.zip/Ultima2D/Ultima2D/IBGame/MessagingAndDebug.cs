#region Using Statements
using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion
using Ultima2D.Ultima;
using Ultima2D.IBLib;
using Ultima2D.IBGame;
namespace Ultima2D
{
    public partial class Ultima2D : Microsoft.Xna.Framework.Game
    {
        string[] gameMessages;
        int gameMessagesCount = 2;
        string debugData;
        bool showGameMessages = true;

        void initializeMessages()
        {
            gameMessages = new string[gameMessagesCount];
            resetMessages();
            sayMessage("[!] Messaging system reset. Limit: "+gameMessagesCount.ToString()+" messages.");
        }

        public void sayMessage(string msg)
        {
            for (int i = 0; i < gameMessagesCount - 1; i++)
            {
                gameMessages[i] = gameMessages[i + 1];
            }
            gameMessages[gameMessagesCount - 1] = msg;
        }
        public string getMessages()
        {
            string r = "";
            foreach (string m in gameMessages)
            {
                r += m + "\n";
            }
            return r;
        }
        public void resetMessages()
        {
            for (int i = 0; i < gameMessagesCount; i++)
            {
                gameMessages[i] = "";
            }
        }

        void getDebugData()
        {
            DebugAdd((stickToThePlayer ? "Sticked to the player. *** " : "")+(gameRunning ? "Game is running." : ""));
            DebugAdd("Camera is @(" + offsetPoint.X.ToString() + "," + offsetPoint.Y.ToString() + ")");
            DebugAdd(world.debugMessage);
        }
        void resetDebugData()
        {
            debugData = "";
        }
        void DebugAdd(string msg)
        {
            if (msg == "") return;
            debugData += msg + "\n";
        }
    }
}