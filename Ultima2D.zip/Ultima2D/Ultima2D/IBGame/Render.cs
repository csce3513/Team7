#region Using Statements
using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion
using Ultima2D.Ultima;
using Ultima2D.IBLib;
using Ultima2D.IBGame;
namespace Ultima2D
{
    public partial class Ultima2D : Microsoft.Xna.Framework.Game
    {
        void InitializeGraphics()
        {
            initializeTextures();
        }
        protected override void Draw(GameTime gameTime)
        {
            switch (state)
            {
                case GameState.Playing:
                    DrawGame(gameTime); break;
            }
            base.Draw(gameTime);
        }
        void DrawGame(GameTime gameTime)
        {
            #region Graphics Init
            graphics.GraphicsDevice.Clear(Color.Black);

            graphics.GraphicsDevice.Viewport = scrolledViewPort;
            device = graphics.GraphicsDevice;

            SpriteBatch sb = new SpriteBatch(device);
            #endregion
            sb.Begin(SpriteBlendMode.AlphaBlend);
            #region Draw Backgrounds
            sb.Draw(getTexture("goo1"), Geometry2D.moveRectangle(world.getArea(), offsetPoint), Color.White);
            #endregion
            #region Draw Walls (Back)
            List<Surface> forewalls = new List<Surface>();
            for (int i = 0; i < world.columns; i++)
            {
                for (int j = 0; j < world.rows; j++)
                {
                    if (world.walls[i, j].Type != SurfaceTypes.Empty && world.walls[i, j].Type != SurfaceTypes.Limiter)
                        if (world.walls[i, j].Type != SurfaceTypes.SemiWall)
                        {
                            forewalls.Add(world.walls[i, j]);
                        }
                        else
                        {
                            sb.Draw(
                                getTexture(world.walls[i, j].code),
                                new Rectangle(
                                            i * (int)world.blockSize.X + offsetPoint.X,
                                            j * (int)world.blockSize.Y + offsetPoint.Y,
                                            (int)world.blockSize.X,
                                            (int)world.blockSize.Y
                                    ),
                                Color.White);
                        }
                }
            }
            #endregion
            #region Draw Entities
            //Draw Entities
            foreach (Entity e in world.entities)
            {
                sb.Draw(getTexture(e.getTextureName()), Geometry2D.moveRectangle(e.bounds, offsetPoint), e.TintColor);
            }
            sb.Draw(getTexture(world.player.getTextureName()), Geometry2D.moveRectangle(world.player.bounds, offsetPoint), world.player.TintColor);
            //sb.Draw(getTexture("player"), Geometry2D.moveRectangle( world.player.bounds,offsetPoint),Color.White);//Draw Our Dude
            /*if (world.player.direction == Directions.Right)
                sb.Draw(getTexture("keenRunRight"), Geometry2D.moveRectangle(world.player.bounds, offsetPoint), Color.White);//Draw Our Dude
            else if (world.player.direction == Directions.Left)
                sb.Draw(getTexture("keenRunLeft"), Geometry2D.moveRectangle(world.player.bounds, offsetPoint), Color.White);//Draw Our Dude*/
            #endregion
            #region Draw Fore Walls
            foreach (Surface s in forewalls)
            {
                sb.Draw(
                  getTexture(s.code),
                  Geometry2D.moveRectangle(s.bounds, offsetPoint),
                  Color.White);
            }
            #endregion
            #region Debug Drawing
            if (debugMode)
            {
                DrawShadowedString(sb, debugFont, debugData, new Vector2(0, 0), Color.Red, Color.Black);
            }
            #endregion
            #region Game Messages
            if (showGameMessages)
            {
                DrawShadowedString(sb, messageFont, getMessages(), new Vector2(0, GameHeight - 24 * gameMessagesCount), Color.White, Color.Black);
            }
            #endregion
            #region Mouse and Stuff
            if (useMouse)
                sb.Draw(getTexture("mouse"), new Rectangle(mousePosition.X, mousePosition.Y, 16, 16), Color.White);
            #endregion
            sb.End();
        }
        void DrawShadowedString(SpriteBatch sb, SpriteFont sf, string msg, Vector2 v, Color foreColor, Color shadowColor)
        {
            sb.DrawString(sf, msg, new Vector2(v.X + 1, v.Y + 1), shadowColor);
            sb.DrawString(sf, msg, v, foreColor);
        }
    }
}
