#region Using Statements
using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion
using Ultima2D.Ultima;
using Ultima2D.IBLib;
namespace Ultima2D
{
    public partial class Ultima2D : Microsoft.Xna.Framework.Game
    {
        string getNameFromPath(string path)
        {
            int bs = 0;
            string fname = "";
            for (int i = path.Length - 1; i >= 0; i--)
            {
                if (path[i] == '\\')
                {
                    bs = i;
                    break;
                }
            }
            for (int i = bs + 1; i < path.Length; i++)
            {
                fname += path[i].ToString();
            }
            return fname;
        }

        string getTime(TimeSpan t)
        {
            return t.Hours.ToString() + "h:" + t.Minutes.ToString() + "m:" + t.Seconds.ToString() + "s,     (" + t.Milliseconds.ToString() + "ms " +
                t.Ticks.ToString() + "tks.)";
        }
    }
}