#region Using Statements
using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion
using Ultima2D.Ultima;
using Ultima2D.IBLib;
namespace Ultima2D
{
    public partial class Ultima2D : Microsoft.Xna.Framework.Game
    {
        void LoadTexture(string path)
        {
            string textureName = getNameFromPath(path).ToLowerInvariant();
            textures.Add(textureName , 
                new IBTexture(textureName,
                Content.Load<Texture2D>(path)));
        }
        void LoadTexture(string path,string name)
        {
            textures.Add(name.ToLowerInvariant(),
                new IBTexture(name,
                Content.Load<Texture2D>(path)));
        }
        void LoadTexture( string name, double frameRate, params string[] paths)
        {
            List<Texture2D> frames = new List<Texture2D>();
            foreach (string path in paths)
            {
                frames.Add( 
                    Content.Load<Texture2D>(path));
            }
            textures.Add(name.ToLowerInvariant(),
                new IBTexture(name,
                frames, frameRate));
        }
        //void LoadAnimation
        Texture2D getTexture(string name)
        {
            //return textures[name.ToLowerInvariant()].getTexture(gamesTime);
            try
            {
                return textures[name.ToLowerInvariant()].getTexture(gamesTime);
            }
            catch
            {
                return getTexture("Error");
            }
        } //Texture using default time
        Texture2D getTexture(string name, GameTime gt)
        {
            try
            {
                return textures[name.ToLowerInvariant()].getTexture(gt);
            }
            catch
            {
                return getTexture("Error");
            }
        }
    }
}