#region Using Statements
using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
#endregion
using Ultima2D.Ultima;
using Ultima2D.IBLib;
namespace Ultima2D
{
    public partial class Ultima2D : Microsoft.Xna.Framework.Game
    {
        protected override void Update(GameTime gameTime)
        {
            HandleKeys(gameTime);

            // TODO: Add your update logic here
            behave(gameTime);
            
            base.Update(gameTime);
        }
    }
}