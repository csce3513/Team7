﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ultima2D.IBLib
{
    public enum Directions    {        Left,Right,Up,Down       }
}
