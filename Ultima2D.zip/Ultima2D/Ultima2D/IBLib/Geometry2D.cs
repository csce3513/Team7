﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
namespace Ultima2D.IBLib
{
    public static class Geometry2D
    {
        public static Vector2 MoveInCircle(GameTime gameTime, float speed)
        {
            double time = gameTime.TotalGameTime.TotalSeconds * speed;

            float x = (float)Math.Cos(time);
            float y = (float)Math.Sin(time);

            return new Vector2(x, y);
        }

        public static Rectangle moveRectangle(Rectangle r, Point offset)
        {
            return new Rectangle(r.X + offset.X, r.Y + offset.Y,
                r.Width, r.Height);
        }
    }
}
