using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
namespace Ultima2D.IBLib
{
    public static class IBDirectionsHelper
    {
        public static void MovePoint(ref Point point, Directions direction, int speed)
        {
            switch (direction)
            {
                case Directions.Up:
                    point.Y -= speed;
                    break;
                case Directions.Down:
                    point.Y += speed;
                    break;
                case Directions.Left:
                    point.X -= speed;
                    break;
                case Directions.Right:
                    point.X += speed;
                    break;
            }
        }
        public static void MoveRect(ref Rectangle rect, Directions direction, int speed)
        {
            switch (direction)
            {
                case Directions.Up:
                    rect.Y -= speed;
                    break;
                case Directions.Down:
                    rect.Y += speed;
                    break;
                case Directions.Left:
                    rect.X -= speed;
                    break;
                case Directions.Right:
                    rect.X += speed;
                    break;
            }
        }
        public static void ReverseDirection(ref Directions d)
        {
            switch (d)
            {
                case Directions.Up:
                    d = Directions.Down;
                    break;
                case Directions.Down:
                    d = Directions.Up;
                    break;
                case Directions.Left:
                    d = Directions.Right;
                    break;
                case Directions.Right:
                    d = Directions.Left;
                    break;
            }
        }
    }
}
