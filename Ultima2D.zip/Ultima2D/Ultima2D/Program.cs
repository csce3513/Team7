using System;

namespace Ultima2D
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        static void Main(string[] args)
        {
            using (Ultima2D game = new Ultima2D())
            {
                game.Window.Title = "[RedBulb in copyright infringment] Preview on " + game.Window.ScreenDeviceName;
                game.Run();
            }
        }
    }
}

