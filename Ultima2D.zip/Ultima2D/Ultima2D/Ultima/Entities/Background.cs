using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Ultima2D.IBLib;
namespace Ultima2D.Ultima.Entities
{
    class Background : Entity
    {

        //public Directions direction;
        public Vector2 position;
        public Background(Rectangle b, String textureName, World w)
        {
            Alive = false;
            world = w;
            Type = EntityTypes.Blank;
            bindToGravity = false;
            StateTexture[EntityStates.Idle] = textureName;
            bounds = b;
            RegenBounds();
        }

        public override void Behave()
        {
        }
        public override void Clip() 
        {

        }

    }
}
