using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Ultima2D.IBLib;
namespace Ultima2D.Ultima
{
    class MovingPlatformH : MovingPlatform
    {
        public MovingPlatformH(Vector2 v, World w)
        {
            direction = Directions.Left;
            world = w;
            bounds = new Rectangle((int)v.X, (int)v.Y, 64, 28);
            RegenBounds();
        }
    }
    class MovingPlatformV : MovingPlatform
    {
        public MovingPlatformV(Vector2 v, World w)
        {
            direction = Directions.Down;
            world = w;
            bounds = new Rectangle((int)v.X, (int)v.Y, 64, 28);
            RegenBounds();
        }
    }

    class MovingPlatform : Entity
    {
        public int speed = 4;
        public MovingPlatform()
        {
            bindToMovingPlatforms = false;
            shootable = true;
            name = "MovingPlatform";
            Immortal = true;
            Alive = true;
            Type = EntityTypes.Creature;
            bindToGravity = false;
            StateTexture[EntityStates.Idle] = "movingPlatform";
            StateTexture[EntityStates.Moving] = "movingPlatform";
            StateTexture[EntityStates.MovingLeft] = "movingPlatformLeft";
            StateTexture[EntityStates.MovingRight] = "movingPlatformRight";
            StateTexture[EntityStates.MovingUp] = "movingPlatformUp";
            StateTexture[EntityStates.MovingDown] = "movingPlatformDown";
        }

        public override void Behave()
        {
            IBDirectionsHelper.MoveRect(ref bounds, direction, speed);
        }

        public override void HitWall()
        {
            IBDirectionsHelper.ReverseDirection(ref direction);
            base.HitWall();
        }

        public override void Clip()
        {
            foreach (Surface w in world.walls)
            {
                if (w.bounds.Intersects(bounds) && (w.Type == SurfaceTypes.Wall || w.Type==SurfaceTypes.Limiter))
                {
                    if (w.bounds.Intersects(RLeft))
                    {
                        bounds.Offset(w.bounds.Right - RLeft.Left, 0);
                        RegenBounds();
                    }
                    if (w.bounds.Intersects(RRight))
                    {
                        bounds.X -= RRight.Right - w.bounds.Left;
                        RegenBounds();
                    }
                    if (w.bounds.Intersects(RBottom))
                    {
                        bounds.Y = w.bounds.Top - bounds.Height;
                        onGround(); RegenBounds();
                    }
                    if (w.bounds.Intersects(RTop))
                    {
                        bounds.Y = w.bounds.Bottom; RegenBounds();
                    }
                    HitWall();
                }
                if (w.bounds.Intersects(bounds) && w.Type == SurfaceTypes.SemiWall)
                {
                    if (w.bounds.Intersects(RBottom))
                    {
                        bounds.Y = w.bounds.Top - bounds.Height;
                        onGround(); RegenBounds();
                    }
                }
            }
        }
        public override void Intersects(Entity e)
        {
            if (!e.bindToMovingPlatforms) return;
            if (e.bounds.Intersects(RTop))
            {
                TintColor = Color.Blue;
                IBDirectionsHelper.MoveRect(ref e.bounds, direction, speed);
                e.bounds.Y = bounds.Top - e.bounds.Height;
                e.onGround();
                e.RegenBounds();
                e.Clip();
            }
            base.Intersects(e);
        }

        public override void Touch()
        {
            Intersects(world.player);
            base.Touch();
        }
    }

}