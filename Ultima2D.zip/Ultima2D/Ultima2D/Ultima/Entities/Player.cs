﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Ultima2D.IBLib;
namespace Ultima2D.Ultima.Entities
{
    class Player:Entity 
    {
        
        public int speed,jumpSpeed,jumpStrength;
        //public Directions direction;
        int maxJumpStrength;
        public int ammo=100, ammoclip = 1;
        //World world;
        public Player(Vector2 position, World w)
        {
            Alive = true;
            direction = Directions.Right;
            bounds = new Rectangle((int)position.X, (int)position.Y,38, 60);
            
            //Clippin Rects
            RegenBounds();
            Type = EntityTypes.Player;
            speed = 5;
            jumpSpeed = 10;
            jumpStrength = maxJumpStrength = 260;
            world = w;

            StateTexture[EntityStates.Idle] = "right_still";
            StateTexture[EntityStates.MovingRight] = "keenRunRight";
            StateTexture[EntityStates.MovingLeft] = "keenRunLeft";
        }
        public void Move(Directions d)
        {
            if (d == Directions.Left)
            {
                MoveLeft(); 
            }
            else if (d == Directions.Right) { MoveRight(); }
        }
        public void DontMove()
        {
            StateTexture[EntityStates.Idle] = (direction==Directions.Right? "right_still":"left_still");
            State = EntityStates.Idle;
        }
        public void MoveRight()
        {
            bounds.X += speed; RegenBounds();
            direction = Directions.Right; State = EntityStates.MovingRight;
        }

        public void MoveLeft()
        {
            bounds.X -= speed; RegenBounds();
            direction = Directions.Left; State = EntityStates.MovingLeft;
        }

        public void JumpUp()
        {
            if (jumpStrength > 0)
            {
                jumpStrength -= jumpSpeed;
                bounds.Y -= jumpSpeed;
            }
            RegenBounds();
        }
        public override void onGround()
        {
            /*if (jumpStrength < maxJumpStrength)
                jumpStrength += 5;
            if (jumpStrength > maxJumpStrength)
                jumpStrength = maxJumpStrength;*/
            jumpStrength = maxJumpStrength;
        }

        public override void Behave()
        {
        }

        public override void Clip()
        {
            foreach (Surface w in world.walls)
            {
                if (w.bounds.Intersects(bounds) && w.Type == SurfaceTypes.Wall)
                {
                    if (w.bounds.Intersects(RLeft))
                    {
                        bounds.Offset(w.bounds.Right - RLeft.Left, 0);
                        RegenBounds();
                    }
                    if (w.bounds.Intersects(RRight))
                    {
                        bounds.X -= RRight.Right - w.bounds.Left;
                        RegenBounds();
                    }
                    if (w.bounds.Intersects(RBottom))
                    {
                        bounds.Y = w.bounds.Top - bounds.Height;
                        onGround(); RegenBounds();
                    }
                    if (w.bounds.Intersects(RTop))
                    {
                        bounds.Y = w.bounds.Bottom; jumpStrength = 0; RegenBounds();
                    }
                }
                if (w.bounds.Intersects(bounds) && w.Type == SurfaceTypes.SemiWall)
                {
                    if (w.bounds.Intersects(RBottom))
                    {
                        bounds.Y = w.bounds.Top - bounds.Height;
                        onGround(); RegenBounds();
                    }
                }
            }
        }

        public override void Shoot()
        {
            if (ammoclip <= 0) return;
            ammoclip = 0;
            ammo--;
            base.Shoot();
        }
    }
}
