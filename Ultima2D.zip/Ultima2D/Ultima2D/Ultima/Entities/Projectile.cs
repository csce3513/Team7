using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Ultima2D.IBLib;
namespace Ultima2D.Ultima.Entities
{
    class Projectile:Entity
    {
        
        //public Directions direction;
        public Vector2 position;
        public int speed = 10;
        public Entity parent;
        public Projectile(Vector2 p,World w, Directions d, Entity daddy)
        {
            parent = daddy;
            Alive = true;
            direction = d;
            world = w;
            position = p;
            Type = EntityTypes.Projectile;
            bindToGravity = false;
            StateTexture[EntityStates.MovingDown] = "projectileDown";
            StateTexture[EntityStates.MovingUp] = "projectileUp";
            StateTexture[EntityStates.MovingRight] = "projectileRight";
            StateTexture[EntityStates.MovingLeft] = "projectileLeft";

            if (direction == Directions.Right || direction == Directions.Left) MakeH();
            else MakeV();
        }

        void MakeH()
        {
            bounds = new Rectangle((int)position.X, (int)position.Y, 30, 10);
            RegenBounds();
        }

        void MakeV()
        {
            bounds = new Rectangle((int)position.X, (int)position.Y, 10, 30);
            RegenBounds();
        }

        public override void Behave()
        {
            IBDirectionsHelper.MoveRect(ref bounds, direction, speed);
        }

        public override void Clip() // Temp
        {
            if (!Alive) return;
            foreach (Surface w in world.walls)
            {
                if (w.bounds.Intersects(bounds) && w.Type == SurfaceTypes.Wall)
                {
                    garbage = true;
                }
            }
        }

        public override void Die()
        {
            garbage = true;
        }

    }
}
