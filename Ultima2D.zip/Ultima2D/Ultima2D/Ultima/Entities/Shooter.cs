using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Ultima2D.IBLib;
namespace Ultima2D.Ultima.Entities
{
    class Shooter : Entity
    {
        public int rate=1000;
        public bool enabled = true;
        public Shooter(Vector2 v, Directions d, World w)
        {
            //shootable = false;
            direction = d;
            name = "Shooter";
            Immortal = true;
            Alive = true;
            world = w;
            Type = EntityTypes.Creature;
            bindToGravity = true;
            StateTexture[EntityStates.Idle] = "shooter";
            StateTexture[EntityStates.Firing] = "shootershooting";
            bounds = new Rectangle((int)v.X, (int)v.Y, 32, 64);
            RegenBounds();
        }

        public override void Behave()
        {
            if ((int)(world.time.TotalGameTime.TotalMilliseconds) % rate==0) Shoot();
        }
    }
}
