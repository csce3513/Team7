using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Ultima2D.IBLib;
namespace Ultima2D.Ultima.Entities
{
    class Teleporter : Entity
    {
        public int teleporterId;
        public Teleporter(Vector2 v, int Id, World w)
        {
            shootable = false;
            teleporterId = Id;
            name = "Teleporter";
            Immortal = true;
            Alive = true;
            world = w;
            Type = EntityTypes.Creature ;
            bindToGravity = false;
            StateTexture[EntityStates.Idle] = "teleporter";
            StateTexture[EntityStates.SpecialState1] = "teleporting";
            bounds = new Rectangle((int)v.X, (int)v.Y, 33, 65);
            RegenBounds();
        }

        public override void Behave()
        {
        }
        public override void Clip()
        {

        }
        public override void Touch()
        {
            foreach (Entity e in world.entities)
            {
                if (e.name == "TeleporterDest")
                    if (((TeleporterDest)e).teleporterId == this.teleporterId) world.teleportPlayer(new Point(e.bounds.X, e.bounds.Y));
            }
            base.Touch();
        }
    }

    class HeavyTeleporter : Entity
    {
        public HeavyTeleporter(Vector2 v, World w)
        {
            bindToMovingPlatforms = false;
            shootable = false;
            name = "HeavyTeleporter";
            Immortal = true;
            Alive = true;
            world = w;
            Type = EntityTypes.Creature;
            bindToGravity = false;
            StateTexture[EntityStates.Idle] = "heavyteleporter";
            StateTexture[EntityStates.SpecialState1] = "heavyteleporting";
            bounds = new Rectangle((int)v.X, (int)v.Y, 64, 64);
            RegenBounds();
        }

        public override void Touch()
        {
            base.Touch();
            world.advanceALevel();
        }
    }

    class TeleporterDest : Entity
    {
        public int teleporterId = 0;
        public TeleporterDest(Vector2 v, int Id, World w)
        {
            shootable = false;
            teleporterId = Id;
            name = "TeleporterDest";
            Immortal = true;
            Alive = true;
            world = w;
            Type = EntityTypes.Creature;
            bindToGravity = false;
            StateTexture[EntityStates.Idle] = "teleporterDest";
            StateTexture[EntityStates.SpecialState1] = "teleporting";
            bounds = new Rectangle((int)v.X, (int)v.Y, 33, 65);
            RegenBounds();
        }

        public override void Behave()
        {
        }
        public override void Clip()
        {

        }
        public override void Touch()
        {
            
        }
    }
}
