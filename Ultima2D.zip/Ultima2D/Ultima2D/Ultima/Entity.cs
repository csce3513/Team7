﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Ultima2D.IBLib;
using Ultima2D.Ultima.Entities;
using Microsoft.Xna.Framework.Graphics;
namespace Ultima2D.Ultima
{
    class Entity
    {
        public int behaveSpeed = 2;
        public Color TintColor = Color.White;
        public string name = "Entity";
        public bool Immortal = false;
        public bool bindToGravity = true;
        public bool bindToMovingPlatforms = true;
        public bool shootable = true;
        public bool dying = false;
        public bool garbage = false;
        public int deathLength = 1000;
        public TimeSpan deathTime;
        public Directions direction;
        public Dictionary<EntityStates, string> StateTexture;
        public Rectangle bounds;
        public Rectangle RBottom, RTop, RLeft, RRight,RBody;
        public EntityTypes Type;
        public EntityStates State=EntityStates.Idle;
        int clipoffset = 5;
        public World world;
        public bool Alive=false;
        public Entity()
        {
            deathTime = new TimeSpan();
            StateTexture = new Dictionary<EntityStates, string>();
            StateTexture.Add(EntityStates.Dead, "");
            StateTexture.Add(EntityStates.Dying, "");
            StateTexture.Add(EntityStates.Firing, "");
            StateTexture.Add(EntityStates.Frozen, "");
            StateTexture.Add(EntityStates.Idle, "");
            StateTexture.Add(EntityStates.Moving, "");
            StateTexture.Add(EntityStates.MovingDown, "");
            StateTexture.Add(EntityStates.MovingLeft, "");
            StateTexture.Add(EntityStates.MovingRight, "");
            StateTexture.Add(EntityStates.MovingUp, "");
            StateTexture.Add(EntityStates.Jumping, "");
            StateTexture.Add(EntityStates.Falling, "");
        }

        public virtual void Behave()
        {
        }
        public virtual void Shot()
        {
            if (Immortal) return;
            Die();
        }
        public virtual void Touch()
        {
        }
        public virtual void Die()
        {
            dying = true;
            Alive = false;
            Type = EntityTypes.Garbage;
            State = EntityStates.Dying;
            deathTime = world.time.TotalGameTime.Duration();
            world.DebugAdd("Dead");
        }
        public virtual void BecomeGarbage()
        {
            world.DebugAdd(world.time.TotalGameTime.Subtract(deathTime).TotalMilliseconds.ToString());
            if (world.time.TotalGameTime.Subtract(deathTime).TotalMilliseconds > deathLength)
                garbage = true;
        }
        public virtual string getTextureName()
        {
            return StateTexture[State];
        }
        public virtual void onGround()
        {
        }
        public virtual void Shoot()
        {
            State = EntityStates.Firing;
            Vector2 v=new Vector2(bounds.Left,bounds.Top);
            switch (direction)
            {
                case Directions.Left:
                    v = new Vector2(bounds.Left - 31, bounds.Y + bounds.Height / 2);
                    break;
                case Directions.Right:
                    v = new Vector2(bounds.Right + 1, bounds.Y + bounds.Height / 2);
                    break;
                case Directions.Up:
                    v = new Vector2(bounds.X+bounds.Width / 2, bounds.Top - 1);
                    break;
                case Directions.Down:
                    v = new Vector2(bounds.X+bounds.Width / 2, bounds.Bottom + 1);
                    break;
            }
            world.AddProjectile(v, direction, this);
        }
        public virtual void Clip()
        {
            if (!Alive) return;
            foreach (Surface w in world.walls)
            {
                if (w.bounds.Intersects(bounds) && w.Type == SurfaceTypes.Wall)
                {
                    if (w.bounds.Intersects(RLeft))
                    {
                        bounds.Offset(w.bounds.Right - RLeft.Left, 0);
                        RegenBounds();
                    }
                    if (w.bounds.Intersects(RRight))
                    {
                        bounds.X -= RRight.Right - w.bounds.Left;
                        RegenBounds();
                    }
                    if (w.bounds.Intersects(RBottom))
                    {
                        bounds.Y = w.bounds.Top - bounds.Height;
                        onGround(); RegenBounds();
                    }
                    if (w.bounds.Intersects(RTop))
                    {
                        bounds.Y = w.bounds.Bottom; RegenBounds();
                    }
                    HitWall();
                }
                if (w.bounds.Intersects(bounds) && w.Type == SurfaceTypes.SemiWall)
                {
                    if (w.bounds.Intersects(RBottom))
                    {
                        bounds.Y = w.bounds.Top - bounds.Height;
                        onGround(); RegenBounds();
                    }
                }
            }
        }
        public virtual void HitWall()
        {
        }

        public virtual void Intersects(Entity e)
        {
        }



        public virtual void RegenBounds()
        {
            RBody = bounds;
            RLeft = new Rectangle(RBody.Left, RBody.Top+clipoffset, 1, RBody.Height-(2*clipoffset));
            RRight = new Rectangle(RBody.Right, RBody.Top+clipoffset, 1, RBody.Height-(2*clipoffset) );
            RTop = new Rectangle(RBody.Left+clipoffset , RBody.Top, RBody.Width-(2*clipoffset) , 1);
            RBottom = new Rectangle(RBody.Left+clipoffset , RBody.Bottom, RBody.Width-(2*clipoffset) , 1);
        }
    }
}
