using System;
using System.Collections.Generic;
using System.Text;

namespace Ultima2D.Ultima
{
    public enum EntityStates
    {
        Idle, Moving, MovingLeft, MovingRight, MovingUp, MovingDown, Firing, Dying, Dead, Frozen, Jumping, Falling,
        SpecialState1, SpecialState2, SpecialState3
    }
}
