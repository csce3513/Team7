﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ultima2D.Ultima
{
    enum EntityTypes
    {
        Blank,
        Player,
        Creature,
        Projectile,
        Wall,
        Item,
        Garbage
    }
}
