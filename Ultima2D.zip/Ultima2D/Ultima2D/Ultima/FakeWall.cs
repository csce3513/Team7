﻿using System;
using System.Collections.Generic;
using System.Text;
using Ultima2D.Ultima;
using Microsoft.Xna.Framework;
namespace Ultima2D.Ultima
{
    class FakeWall:Surface  
    {
       
        public FakeWall(Point position)
        {
            bounds = new Rectangle(position.X, position.Y, 
                BlockConstants.BlockWidth, BlockConstants.BlockHeight);
         //   RegenBounds();
            Type = SurfaceTypes.FakeWall;
        }

        public FakeWall(Point position, char c)
        {
            bounds = new Rectangle(position.X, position.Y,
                BlockConstants.BlockWidth, BlockConstants.BlockHeight); //RegenBounds();
            Type = SurfaceTypes.FakeWall;
            code = c;
        }

        public override void Clip(ref Entity e)
        {
            /*if (Intersects(e))
            {
                e.bounds.Offset(e.bounds.X, bounds.Y - e.bounds.Height);
            }*/
        }
    }
}
