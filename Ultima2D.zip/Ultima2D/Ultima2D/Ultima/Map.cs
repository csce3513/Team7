﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ultima2D.Ultima
{
    class Map
    {
        public string mapData;
        public int Width,Height;
    }
}
