﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Ultima2D.Ultima.Entities;
using Microsoft.Xna.Framework.Graphics;
using Ultima2D.IBLib;
namespace Ultima2D.Ultima
{
    static class MapFile
    {
        public static Surface[,] LoadMap(Map map,ref List<Entity> entities,World w)
        {
            Surface[,] s = new Surface[map.Width, map.Height];
            int c = 0;
            entities.Add(new Player(new Vector2(),w));
            for (int j = 0; j < map.Height ; j++)
            {
                for (int i = 0; i < map.Width ; i++,c++)
                {
                    switch (map.mapData[c])
                    {
                        /*case 'X' || '1' || '2' || '3' || '4' || '5'
                        || '6' || '7' || '8' || 't' || 'c' || 'b'
                        || '!' || '@' || '#' || '$':*/
                        case 't': //teleporter class 1
                            entities.Add(new Teleporter(new Vector2((int)(i * BlockConstants.BlockWidth), (int)(j * BlockConstants.BlockHeight)), 1, w));
                            s[i, j] = new Surface();
                            break;
                        case 'd':
                            entities.Add(new TeleporterDest(new Vector2((int)(i * BlockConstants.BlockWidth), (int)(j * BlockConstants.BlockHeight)), 1, w));
                            s[i, j] = new Surface();
                            break;
                        case 'T': //teleporter class 2
                            entities.Add(new Teleporter(new Vector2((int)(i * BlockConstants.BlockWidth), (int)(j * BlockConstants.BlockHeight)), 2, w));
                            s[i, j] = new Surface();
                            break;
                        case 'D':
                            entities.Add(new TeleporterDest(new Vector2((int)(i * BlockConstants.BlockWidth), (int)(j * BlockConstants.BlockHeight)), 2, w));
                            s[i, j] = new Surface();
                            break;
                        case 'H': // heavy teleporter
                            entities.Add(new HeavyTeleporter(new Vector2((int)(i * BlockConstants.BlockWidth), (int)(j * BlockConstants.BlockHeight)),w));
                            s[i, j] = new Surface();
                            break;
                        case 'e': // elevator: h
                            entities.Add(new MovingPlatformH(new Vector2((int)(i * BlockConstants.BlockWidth), (int)(j * BlockConstants.BlockHeight)), w));
                            s[i, j] = new Surface(); 
                            break;
                        case 'E': // elevator: v
                            entities.Add(new MovingPlatformV(new Vector2((int)(i * BlockConstants.BlockWidth), (int)(j * BlockConstants.BlockHeight)), w));
                            s[i, j] = new Surface();
                            break;
                        case 's': // shooter: left
                            entities.Add(new Shooter(new Vector2((int)(i * BlockConstants.BlockWidth), (int)(j * BlockConstants.BlockHeight)),Directions.Left, w));
                            s[i, j] = new Surface();
                            break;
                        case 'S': // shooter: right
                            entities.Add(new Shooter(new Vector2((int)(i * BlockConstants.BlockWidth), (int)(j * BlockConstants.BlockHeight)), Directions.Right, w));
                            s[i, j] = new Surface();
                            break;
                        case 'P':
                            entities.Add(new Player(new Vector2((int)(i * BlockConstants.BlockWidth), (int)(j * BlockConstants.BlockHeight)), w));
                            s[i, j] = new Surface();
                            break;
                        case 'O':
                            entities.Add(new Background(new Rectangle(i * BlockConstants.BlockWidth, j * BlockConstants.BlockHeight,
                                320, 64), "ibeambanner", w));
                            s[i, j] = new Surface();
                            break;
                        case 'p':
                            entities[0] = new Player(new Vector2(i * BlockConstants.BlockWidth, j * BlockConstants.BlockHeight), w);
                            s[i, j] = new Surface();
                            break;
                        case ' ':
                            s[i, j] = new Surface();
                            break;
                        default:
                            if (map.mapData[c] == 'u' || map.mapData[c] == 'C' || map.mapData[c] == 'b')
                            {
                                s[i, j] = new FakeWall(new Point(i * BlockConstants.BlockWidth
                            , j * BlockConstants.BlockHeight), map.mapData[c]);
                            break;
                            }
                            if (map.mapData[c] == '1')
                            {
                                s[i, j] = new SemiWall(new Point(i * BlockConstants.BlockWidth
                            , j * BlockConstants.BlockHeight), map.mapData[c]);
                                break;
                            }
                            if (map.mapData[c] == '~')
                            {
                                s[i, j] = new Limiter(new Point(i * BlockConstants.BlockWidth
                            , j * BlockConstants.BlockHeight), map.mapData[c]);
                                break;
                            }
                            s[i, j] = new Wall(new Point (i * BlockConstants.BlockWidth
                            , j * BlockConstants.BlockHeight), map.mapData[c]);
                            break;
                    }
                }
            }
            return s;
        }
    }
}
