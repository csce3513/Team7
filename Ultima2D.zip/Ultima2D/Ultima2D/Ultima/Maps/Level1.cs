﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ultima2D.Ultima.Maps
{
    class Level1 : Map 
    {
        public Level1()
        {
            //         0000000000111111111122222222223333333333444444444455555555556666666666777777777788888888889999999999
            //         0123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789
            mapData = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX" + // 0
                      "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX" + // 1
                      "XXXXX                                                         d                                XXXXX" + // 2
                      "8                                                                                                 u8" + // 3
                      "8           ~                        XXXXXXXXXXXX              s                                  C8" + // 4
                      "8                                    XO         X                                                 C8" + // 5
                      "8222      p         22222222222222222X          X2222222222222222                                 C8" + // 6
                      "82i2                33333333333333333XXXXXXXXXXXX3333333333333333                                 C8" + // 7
                      "8222                                 u          u                                                 C8" + // 8
                      "8u u       E                         C          C                                                 C8" +  // 9
                      "8C C                                 C          C                                                 C8" +  // 0
                      "8C C             e                   C          C                                                 C8" + // 1
                      "8C C                                 C          b                                                 C8" + // 2
                      "8C C        ~  P       P             C 11111111 u                                                 C8" + // 3
                      "8C C                                 b          C                                                 C8" + // 4
                      "8C C                                 u 11111111 C                            ╧222╨                C8" + // 5
                      "8C C  !@#$    !@#$   !@#$            C          C                         ╚╤╤╤╤╤╤╤╤╤╠             C8" + // 6
                      "8C C                                 C 11111111 C  P     H             ╚╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╠          C8" + // 7
                      "7C CS                          t     C          C                   ╚╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╠       C7" + // 8
                      "6b b                                 b          b                ╚╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╠    b6" +  // 9
                      "44444444444444444444444444444444441111111111111111114444444444444╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤444444" +  // 0
                      "5555555555555555555555555555555555111333333333333111555555555555555555555555555555555555555555555555";  // 1
            Width = 100; Height = 22;
        }
    }
}
