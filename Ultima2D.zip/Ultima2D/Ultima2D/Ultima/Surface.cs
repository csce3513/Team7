﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
namespace Ultima2D.Ultima
{
    class Surface
    {
//        public Rectangle RBottom, RTop, RLeft, RRight, RBody;
        //public Texture2D texture;
        public char code;
        public Rectangle bounds;
        public SurfaceTypes Type;
  //      int clipoffset = 3;
        public virtual bool Intersects(Entity e)
        {
            return bounds.Intersects(e.bounds);
        }

        public virtual void Clip(ref Entity e)
        {

        }

        public Surface()
        {
                bounds = new Rectangle();
                Type = SurfaceTypes.Empty;
                code = ' ';
                
        }
    }

    static class BlockConstants
    {
        public static int BlockWidth = 32;
        public static int BlockHeight = 32;
    }

    enum SurfaceTypes
    {
        Empty,
        Wall, FakeWall, SemiWall,
        Limiter
    }




    class Limiter : Surface
    {

        public Limiter(Point position)
        {
            bounds = new Rectangle(position.X, position.Y,
                BlockConstants.BlockWidth, BlockConstants.BlockHeight);
            //   RegenBounds();
            Type = SurfaceTypes.Limiter;
        }

        public Limiter(Point position, char c)
        {
            bounds = new Rectangle(position.X, position.Y,
                BlockConstants.BlockWidth, BlockConstants.BlockHeight); //RegenBounds();
            Type = SurfaceTypes.Limiter;
            code = c;
        }

        public override void Clip(ref Entity e)
        {
            /*if (Intersects(e))
            {
                e.bounds.Offset(e.bounds.X, bounds.Y - e.bounds.Height);
            }*/
        }
    }

}
