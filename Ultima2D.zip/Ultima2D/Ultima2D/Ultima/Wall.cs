﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Ultima2D.Ultima
{
    class Wall:Surface 
    {
        //Constructor
        
        public Wall(Point  position)
        {
            bounds = new Rectangle(position.X, position.Y, 
                BlockConstants.BlockWidth, BlockConstants.BlockHeight);
           // RegenBounds();
            Type = SurfaceTypes.Wall;
        }

        public Wall(Point  position,char c)
        {
            bounds = new Rectangle(position.X, position.Y,
                BlockConstants.BlockWidth, BlockConstants.BlockHeight);
           /// RegenBounds();
            Type = SurfaceTypes.Wall;
            code = c;
        }

        public override void Clip(ref Entity e)
        {
            if (Intersects(e))
            {
                e.bounds.Offset(e.bounds.X, bounds.Y - e.bounds.Height);
            }
        }
    }


}
