﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Ultima2D.IBLib;
using Ultima2D.Ultima.Entities;
using Ultima2D.Ultima.Maps;
using Microsoft.Xna.Framework.Input;
namespace Ultima2D.Ultima
{
    class World
    {
        public int behaveSpeed = 1;

        public string debugMessage = "";
        public Player player;
        public List<Entity> entities;
        public Surface[,] walls;
        public Rectangle bounds;
        public GameTime time;
        public int columns, rows;
        public int gravity;
        public Ultima2D game;
        public Vector2 blockSize;
        public List<Map> Levels;
        public int currentLevel = 0;
        public bool instantTeleport = true;
        public World(Ultima2D g)
        {
            game = g;
            time = g.gamesTime;
            bounds = new Rectangle(0, 0, 800, 600);
            gravity = 5;
            blockSize = new Vector2(32f, 32f);
            InitializeLevels();
            LoadLevel(0);
        }

        public void InitializeLevels()
        {
            Levels = new List<Map>();
            Levels.Add(new Level1());
            Levels.Add(new Level2());
        }

        public void nextLevel()
        {
            currentLevel++;
            if (currentLevel > Levels.Count - 1) currentLevel = 0;
            LoadLevel(currentLevel);
        }

        public void prevLevel()
        {
            currentLevel--;
            if (currentLevel < 0) currentLevel = 0;
            LoadLevel(currentLevel);
        }

        public void advanceALevel()
        {
            game.nextLevel();
        }

        public void warpLevel(int levelno)
        {
            currentLevel = levelno;
            LoadLevel(levelno);
        }
        public void LoadLevel(Map level)
        {
            entities = new List<Entity>();
            entities.Add(new Player(new Vector2(), this));
            walls = MapFile.LoadMap(level, ref entities,this);
            player = (Player)entities[0];
            columns = level.Width;
            rows = level.Height;
        }
        public void LoadLevel(int levelno)
        {
            sayMessage("Level " + levelno.ToString() + " loaded");
            LoadLevel(Levels[levelno]);
        }
        public Rectangle getArea()
        {
            return new Rectangle(0, 0, columns * (int)blockSize.X, rows * (int)blockSize.Y);
        }
        public void AddProjectile(Vector2 v, Directions d, Entity p)
        {
            entities.Add(new Projectile(v, this, d,p));
        }

        public void teleportPlayer(Point p)
        {
            player.bounds.X = p.X;
            player.bounds.Y = p.Y;
            if (instantTeleport) game.warpCameraToPlayer();
        }
        public void Behave()
        {
            DebugReset();
            DebugAdd(entities[0].Type.ToString()+": ("+entities[0].bounds.X.ToString()+","+entities[0].bounds.Y.ToString()+")");
            DebugAdd("Entities: " + entities.Count);
            time = game.gamesTime;
            DisposeGarbage();
            player.Behave();
            if (player.bindToGravity) player.bounds.Y += (int)gravity;
            player.RegenBounds();
            for (int i = 1; i<entities.Count; i++)
            {
                Entity e = entities[i];
                if (e.Alive)
                {
                    /*if (e.Type == EntityTypes.Projectile && e.bounds.Intersects(player.bounds) && !(((Projectile)e).parent == player))
                    {
                        sayMessage("Projectile shot player in the ass.");
                        player.Shot();
                        e.Die();
                    }*/
                    foreach (Entity e2 in entities)
                    {
                        if (e.bounds.Intersects(e2.bounds) && e != e2)
                        {
                            if (e.Type == EntityTypes.Projectile && e2.shootable && e2.Alive)
                            {
                                if (!(((Projectile)e).parent == e2))
                                sayMessage("Projectile shot "+e2.Type.ToString()+" in the crack.");
                                e2.Shot();
                                e.Die();
                            }
                            else e.Intersects(e2);
                        }
                    }
                    if (e.bounds.Intersects(player.bounds)) e.Touch();
                    //if ((int)(time.TotalGameTime.Milliseconds)%e.behaveSpeed==0)
                        e.Behave();
                    if (e.bindToGravity) e.bounds.Y += (int)gravity;
                    e.RegenBounds();
                }
                if (e.dying) e.BecomeGarbage();
                e.Clip();
            }
            player.Clip();
        }

        public void DisposeGarbage()
        {
            for (int i = 0; i < entities.Count; i++)
            {
                if (entities[i].garbage) entities.RemoveAt(i);
            }
        }

        public void DebugAdd(string s)
        {
            debugMessage += s + '\n';
        }

        public void DebugReset()
        {
            debugMessage = "";
        }
        public void sayMessage(string s)
        {
            game.sayMessage("World: " + s);
        }

        public void HandleKeyboard(KeyboardState state)
        {
            if (state.IsKeyUp(Keys.Space)) player.ammoclip = 1;
            if (state.IsKeyDown(Keys.Right) ||
                state.IsKeyDown(Keys.Left) ||
                state.IsKeyDown(Keys.RightControl) ||
                state.IsKeyDown(Keys.Space))
            {
                if (state.IsKeyDown(Keys.Right)) player.Move(Directions.Right);
                if (state.IsKeyDown(Keys.Left)) player.Move(Directions.Left);
                if (state.IsKeyDown(Keys.RightControl)) player.JumpUp();
                if (state.IsKeyDown(Keys.Space)) player.Shoot();
                //  playerMovement(gameTime);
            }
            else
            {
                player.DontMove();
            }
        }

        public void HandleMouse()
        {
        }
    }
}
